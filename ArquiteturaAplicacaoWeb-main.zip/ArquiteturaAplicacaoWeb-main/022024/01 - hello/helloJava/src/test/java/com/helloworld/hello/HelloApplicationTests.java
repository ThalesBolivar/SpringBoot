package com.example.hello_wold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWoldApplicationTests {

	@Test
	void contextLoads() {
	}

}
