package com.example.tarefa.dto;
;

public record LoginRequest(String username, String password) {
}