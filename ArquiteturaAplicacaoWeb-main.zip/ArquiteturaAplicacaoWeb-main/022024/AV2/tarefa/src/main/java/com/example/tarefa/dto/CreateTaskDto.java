package com.example.tarefa.dto;

public record CreateTaskDto(String content, String descricao, boolean concluida) {
}