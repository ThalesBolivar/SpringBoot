package com.example.tarefa.dto;

public record TaskItemDto(long tweetId, String content, String username) {
}