package com.example.tarefa.dto;

public record CreateUserDto(String username, String password) {
}