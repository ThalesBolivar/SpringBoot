INSERT IGNORE INTO tb_roles (id, name) VALUES (1, 'admin');
INSERT IGNORE INTO tb_roles (id, name) VALUES (2, 'basic');