package tech.buildrun.springsecurity.controller.dto;

public record CreateTweetDto(String content) {
}
