package tech.buildrun.springsecurity.controller.dto;

public record LoginRequest(String username, String password) {
}
