Configuração do Projeto:

Inicializar um novo projeto Node.js.
Instalar as dependências necessárias (express, mongoose, body-parser).
Configuração do Servidor:

Configurar o servidor Express.
Conectar ao banco de dados MongoDB usando Mongoose.
Definição do Modelo:

Criar um modelo Mongoose para a coleção do MongoDB.
Criação das Rotas CRUD:

Criar rotas para criar, ler, atualizar e deletar documentos.
Passo 1: Configuração do Projeto
