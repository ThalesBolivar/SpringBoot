package com.example.render;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(RenderApplication.class, args);
	}

}
