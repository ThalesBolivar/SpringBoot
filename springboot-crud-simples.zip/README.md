# Projeto Spring Boot CRUD Simples

Este projeto implementa um CRUD básico de `Produto` e `Categoria` com relacionamento entre eles, conforme solicitado.

## Banco de dados

Crie o banco no MariaDB:
```sql
CREATE DATABASE produto_categoria_db;
```

## Configuração (application.properties)

```
spring.datasource.url=jdbc:mariadb://localhost:3306/produto_categoria_db
spring.datasource.username=root
spring.datasource.password=
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MariaDBDialect
```

## Como rodar

1. Suba o MariaDB
2. Rode a classe principal `SpringbootCrudApplication.java`